import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Trash2, Thermometer, Baby, Stethoscope, Users, CheckCircle2, Circle, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

type TaskType = "temperature" | "birth" | "disease" | "treatment" | "workers";
type TaskStatus = "pending" | "done";

interface Task {
  id: string;
  title: string;
  description: string;
  type: TaskType;
  worker: string;
  status: TaskStatus;
  createdAt: string;
  completedAt?: string;
}

interface Worker {
  id: string;
  name: string;
}

const typeConfig: Record<TaskType, { label: string; icon: any; color: string }> = {
  temperature: { label: "حرارة", icon: Thermometer, color: "bg-orange-100 text-orange-700" },
  birth: { label: "ولادة", icon: Baby, color: "bg-pink-100 text-pink-700" },
  disease: { label: "مرض", icon: Stethoscope, color: "bg-red-100 text-red-700" },
  treatment: { label: "علاج", icon: AlertCircle, color: "bg-amber-100 text-amber-700" },
  workers: { label: "عمال", icon: Users, color: "bg-blue-100 text-blue-700" },
};

const initialWorkers: Worker[] = [
  { id: "1", name: "محمد" },
  { id: "2", name: "أحمد" },
  { id: "3", name: "خالد" },
];

const initialTasks: Task[] = [
  {
    id: "1",
    title: "قياس حرارة الأغنام",
    description: "قياس حرارة جميع الأغنام في الحظيرة الشمالية",
    type: "temperature",
    worker: "محمد",
    status: "pending",
    createdAt: new Date().toISOString(),
  },
  {
    id: "2",
    title: "متابعة ولادة النعجة",
    description: "متابعة حالة النعجة الحامل رقم 12",
    type: "birth",
    worker: "أحمد",
    status: "done",
    createdAt: new Date().toISOString(),
    completedAt: new Date().toISOString(),
  },
];

export default function App() {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [workers, setWorkers] = useState<Worker[]>(initialWorkers);
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    type: "temperature" as TaskType,
    worker: "",
  });
  const [newWorkerName, setNewWorkerName] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  const addTask = () => {
    if (!newTask.title.trim() || !newTask.worker) return;
    const task: Task = {
      id: Date.now().toString(),
      title: newTask.title,
      description: newTask.description,
      type: newTask.type,
      worker: newTask.worker,
      status: "pending",
      createdAt: new Date().toISOString(),
    };
    setTasks([task, ...tasks]);
    setNewTask({ title: "", description: "", type: "temperature", worker: "" });
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => 
      t.id === id 
        ? { ...t, status: t.status === "done" ? "pending" : "done", completedAt: t.status === "done" ? undefined : new Date().toISOString() }
        : t
    ));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const addWorker = () => {
    if (!newWorkerName.trim()) return;
    const worker: Worker = {
      id: Date.now().toString(),
      name: newWorkerName.trim(),
    };
    setWorkers([...workers, worker]);
    setNewWorkerName("");
  };

  const deleteWorker = (id: string) => {
    setWorkers(workers.filter(w => w.id !== id));
  };

  const filteredTasks = activeTab === "all" 
    ? tasks 
    : activeTab === "pending" 
      ? tasks.filter(t => t.status === "pending")
      : tasks.filter(t => t.status === "done");

  const stats = {
    total: tasks.length,
    pending: tasks.filter(t => t.status === "pending").length,
    done: tasks.filter(t => t.status === "done").length,
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-teal-50">
      <header className="bg-emerald-800 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold font-serif">مزرعة الأغنام</h1>
              <p className="text-emerald-200 mt-1">نظام متابعة المهام والإجراءات</p>
            </div>
            <div className="flex gap-3">
              <div className="bg-emerald-700 rounded-xl px-4 py-2 text-center">
                <div className="text-2xl font-bold">{stats.total}</div>
                <div className="text-xs text-emerald-200">إجمالي المهام</div>
              </div>
              <div className="bg-emerald-700 rounded-xl px-4 py-2 text-center">
                <div className="text-2xl font-bold text-amber-300">{stats.pending}</div>
                <div className="text-xs text-emerald-200">قيد الانتظار</div>
              </div>
              <div className="bg-emerald-700 rounded-xl px-4 py-2 text-center">
                <div className="text-2xl font-bold text-green-300">{stats.done}</div>
                <div className="text-xs text-emerald-200">مكتملة</div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* إضافة مهمة جديدة */}
          <Card className="lg:col-span-2 bg-white shadow-md">
            <CardHeader className="bg-emerald-50 border-b border-emerald-100">
              <CardTitle className="text-xl font-bold text-emerald-900">إضافة مهمة جديدة</CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">عنوان المهمة</Label>
                  <Input
                    id="title"
                    placeholder="مثال: قياس حرارة الأغنام"
                    value={newTask.title}
                    onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                    className="border-emerald-200 focus:border-emerald-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label>نوع المهمة</Label>
                  <Select
                    value={newTask.type}
                    onValueChange={(v: TaskType) => setNewTask({ ...newTask, type: v })}
                  >
                    <SelectTrigger className="border-emerald-200">
                      <SelectValue placeholder="اختر النوع" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(typeConfig).map(([key, config]) => (
                        <SelectItem key={key} value={key}>
                          <span className="flex items-center gap-2">
                            <config.icon className="w-4 h-4" />
                            {config.label}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">وصف المهمة</Label>
                <Textarea
                  id="description"
                  placeholder="تفاصيل إضافية عن المهمة..."
                  value={newTask.description}
                  onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                  className="border-emerald-200 focus:border-emerald-500"
                />
              </div>
              <div className="space-y-2">
                <Label>العامل المسؤول</Label>
                <Select
                  value={newTask.worker}
                  onValueChange={(v) => setNewTask({ ...newTask, worker: v })}
                >
                  <SelectTrigger className="border-emerald-200">
                    <SelectValue placeholder="اختر العامل" />
                  </SelectTrigger>
                  <SelectContent>
                    {workers.map(w => (
                      <SelectItem key={w.id} value={w.name}>{w.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={addTask}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <Plus className="w-4 h-4 ml-2" />
                إضافة المهمة
              </Button>
            </CardContent>
          </Card>

          {/* إدارة العمال */}
          <Card className="bg-white shadow-md">
            <CardHeader className="bg-blue-50 border-b border-blue-100">
              <CardTitle className="text-xl font-bold text-blue-900">إدارة العمال</CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="اسم العامل الجديد"
                  value={newWorkerName}
                  onChange={(e) => setNewWorkerName(e.target.value)}
                  className="border-blue-200 focus:border-blue-500"
                />
                <Button 
                  onClick={addWorker}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="space-y-2">
                {workers.map(w => (
                  <div key={w.id} className="flex items-center justify-between bg-blue-50 rounded-lg px-3 py-2">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-blue-600" />
                      <span className="font-medium">{w.name}</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteWorker(w.id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* قائمة المهام */}
        <Card className="mt-6 bg-white shadow-md">
          <CardHeader className="bg-emerald-50 border-b border-emerald-100">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl font-bold text-emerald-900">قائمة المهام</CardTitle>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="bg-emerald-100">
                  <TabsTrigger value="all" className="data-[state=active]:bg-white">الكل</TabsTrigger>
                  <TabsTrigger value="pending" className="data-[state=active]:bg-white">قيد الانتظار</TabsTrigger>
                  <TabsTrigger value="done" className="data-[state=active]:bg-white">مكتملة</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            {filteredTasks.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>لا توجد مهام في هذا التصنيف</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredTasks.map(task => {
                  const config = typeConfig[task.type];
                  const Icon = config.icon;
                  return (
                    <div
                      key={task.id}
                      className={cn(
                        "flex items-start gap-4 p-4 rounded-xl border transition-all",
                        task.status === "done" 
                          ? "bg-green-50 border-green-200 opacity-75" 
                          : "bg-white border-gray-200 hover:border-emerald-300 hover:shadow-sm"
                      )}
                    >
                      <button
                        onClick={() => toggleTask(task.id)}
                        className="mt-1 flex-shrink-0"
                      >
                        {task.status === "done" ? (
                          <CheckCircle2 className="w-6 h-6 text-green-600" />
                        ) : (
                          <Circle className="w-6 h-6 text-gray-300 hover:text-emerald-500" />
                        )}
                      </button>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={cn("font-medium", config.color)}>
                            <Icon className="w-3 h-3 ml-1" />
                            {config.label}
                          </Badge>
                          <span className="text-sm text-gray-500">العامل: {task.worker}</span>
                        </div>
                        <h3 className={cn(
                          "font-semibold text-gray-900",
                          task.status === "done" && "line-through text-gray-500"
                        )}>
                          {task.title}
                        </h3>
                        {task.description && (
                          <p className="text-sm text-gray-600 mt-1">{task.description}</p>
                        )}
                        <div className="text-xs text-gray-400 mt-2">
                          {task.status === "done" && task.completedAt 
                            ? `تم الإنجاز: ${new Date(task.completedAt).toLocaleDateString("ar-SA")}`
                            : `أضيفت: ${new Date(task.createdAt).toLocaleDateString("ar-SA")}`}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteTask(task.id)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}